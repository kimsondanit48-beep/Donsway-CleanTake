# Dons'way CleanTake (VST3 source project)

A first buildable prototype of a real-time vocal-cleaning insert for Windows/FL Studio.

## Current processing
- Adjustable high-pass filter for low rumble and handling noise.
- Lightweight adaptive broadband downward-expansion for low-level steady noise.
- Dynamic high-frequency attenuation intended to soften harsh upper-mid/high content.
- Gentle, smoothed gate/expander for pauses between phrases.
- Plugin parameters saved with the DAW project.
- VST3 and Standalone targets through JUCE/CMake.

## Important limitations
This is a first DSP prototype, not a finished commercial denoiser. It does **not** yet implement neural or FFT spectral denoising, and cannot reliably remove every kind of electrical crackle, intermittent click, or room reflection. The adaptive broadband stage is intentionally lightweight and may affect quiet vocal details. Listen for artifacts and keep the strength conservative. Good mic technique, gain staging, and fixing electrical/grounding problems remain important.

## Build on Windows
1. Install Visual Studio 2022 with **Desktop development with C++**.
2. Install CMake.
3. Download JUCE from https://juce.com/get-juce/ (JUCE is available under its own licensing terms).
4. Open a Developer PowerShell for VS 2022.
5. From this folder, configure the project. Replace `C:/JUCE` with the folder containing JUCE's `CMakeLists.txt`:

   `cmake -S . -B build -DJUCE_DIR=C:/JUCE -DCMAKE_BUILD_TYPE=Release`

6. Build:

   `cmake --build build --config Release`

7. Find the generated VST3 bundle in the build tree, usually under `DonswayCleanTake_artefacts/Release/VST3/`.
8. In FL Studio, open **Options > Manage plugins**, add the folder containing the VST3, then scan.

If CMake reports a JUCE path issue, JUCE_DIR must point to the JUCE root directory that contains `CMakeLists.txt`.

## Recording setup
Put CleanTake on the vocal input/mixer insert before recording. Use the lowest buffer size that remains stable on your computer. Start with Noise Reduction around 20–35%, Rumble Cut around 70–90 Hz, Harshness around 15–30%, and Gate Strength around 10–25%. Compare bypassed vs enabled and make sure breaths and word endings remain audible.

## Next development milestone
Implement proper STFT/WOLA spectral subtraction with a learned noise profile, click/transient detection, and a calibrated dynamic de-esser. Test latency and artifacts on real recordings before calling it a full noise cleaner.
